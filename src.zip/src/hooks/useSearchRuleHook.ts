import { useState } from "react";
import axios from "axios";
import { RuleData } from "../interfaces/rules";
 function usePostHttp():[string,(url:string,method:string,body:{},action:any)=>void]{
    const [rulesData, setRules] = useState<[]>([]);
    const [errorMessage,setErrorMessage]=useState<string>("")
    function sendHttpRequest(url:string,method:string,body:{},action:any) {
        axios
           .post(url,body)
           .then((res:{data:[]}) => {
            setRules(res.data);
            const arrayRules=rulesData.map((element:RuleData) => {
              return element?.rulesData;
            });
            action(arrayRules);
          })
           .catch((error) => setErrorMessage(error));
        }
   return [errorMessage,sendHttpRequest];
}

export default usePostHttp;