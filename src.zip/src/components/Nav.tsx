import "../styles/index.scss";
import { Link } from "react-router-dom";

 function Nav() {
  return (
    <div className="navbar navbar-expand-lg navbar-light bg-primary">
      <div className="navbar-brand">
        <img
          style={{ height: "60px" }}
          src="https://www.goldmansachs.com/a/pgs/images/logo.svg"
          alt="Goldman"
        ></img>
      </div>
      <ul className="nav-links">
        <Link to="/search" className="nav-link text-light">Search Rules</Link>
        <Link to="/upload" className="text-light">Upload Rules</Link>

      </ul>
    </div>
  );
}

export default Nav;
