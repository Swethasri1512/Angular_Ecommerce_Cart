import { useState, useRef } from "react";
import Form from "react-bootstrap/Form";

 function UploadRule() {
  const ruleDesc = useRef<HTMLInputElement | null>(null); 
  const ruleName = useRef<HTMLInputElement | null>(null); 
  const category = useRef<HTMLInputElement | null>(null); 
  const tag = useRef<HTMLInputElement | null>(null); 
  const subcategory = useRef<HTMLInputElement | null>(null); 
  const ruleId = useRef<HTMLInputElement | null>(null); 
  const [files,setFiles] = useState<any>();
  
  function handleSubmit(event:React.SyntheticEvent) {
    event.preventDefault();
    const request = {
      tag: tag?.current?.value,
      category:category?.current?.value,
      subCategory:subcategory?.current?.value,
      ruleId:ruleId?.current?.value,
      ruleName:ruleName?.current?.value,
      ruleDescription: ruleDesc?.current?.value,
      active: "true",
      ruleDrl: files,
      lastUpdateBy: "Ankit Kumar",
      lastModfiedBy: "23/06/2023",
      version: 1,
    };
  
  }
  const handleChange = (event:React.ChangeEvent) => {
    const fileReader = new FileReader();
    const target= event.target as HTMLInputElement;
    const file: File = (target.files as FileList)[0];
    fileReader.readAsText(file, "UTF-8");
    fileReader.onload = (e:Event) => {
      setFiles(fileReader.result);
    };
  };

  return (
    <div className="container border border-info  bg-light mt-5">
      <div className="d-flex align-items-center justify-content-center">
        <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
            <Form.Label class="text-info">Rule ID</Form.Label>
            <Form.Control
              type="text"
              ref={ruleId}
              placeholder="Please enter rule id"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="ControlInput2">
            <Form.Label class="text-info">Rule Description</Form.Label>
            <Form.Control
              ref={ruleDesc}
              type="text"
              placeholder="Please enter rule description"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="ControlInput3">
            <Form.Label class="text-info">Rule Name</Form.Label>
            <Form.Control
              type="text"
              ref={ruleName}
              placeholder="Please enter rule name"
            />
          </Form.Group>
          
          <Form.Group className="mb-3" controlId="ControlInput4">
            <Form.Label class="text-info">Upload Rule DRL</Form.Label>
            <Form.Control type="file" onChange={handleChange} />
          </Form.Group>
          
          <Form.Group className="mb-3" controlId="ControlInput5">
            <Form.Label class="text-info">Category</Form.Label>
            <Form.Control
              type="text"
              ref={category}
              placeholder="Please enter rule category"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="ControlInput6">
            <Form.Label class="text-info">Sub Category</Form.Label>
            <Form.Control
              type="text"
              ref={subcategory}
              placeholder="Please enter rule subcategory"
            />
          </Form.Group>
          <Form.Group className="mb-3" controlId="ControlInput7">
            <Form.Label class="text-info">Tag</Form.Label>
            <Form.Control
              type="text"
              ref={tag}
              placeholder="Please enter rule name"
            />
          </Form.Group>
          <button  className="btn btn-outline-secondary bg-info  mt-3" type="submit">
            Submit
          </button>
        </Form>
      </div>
    </div>
  );
}


export default UploadRule;