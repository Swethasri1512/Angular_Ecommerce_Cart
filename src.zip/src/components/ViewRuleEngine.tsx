import { QueryBuilder, RuleGroupType } from 'react-querybuilder';
import 'react-querybuilder/dist/query-builder.scss';
import '../styles/styles.scss';
import { QueryBuilderBootstrap } from '@react-querybuilder/bootstrap';
import 'bootstrap-icons/font/bootstrap-icons.scss';
import 'bootstrap/scss/bootstrap.scss';
import  { useState}from 'react';
import { fields } from '../interfaces/fields';

const initialQuery :RuleGroupType= {"rules":[{"rules":[{"field":"Account.entity","value":"GAGM,GSGG,GSFR","operator":"contains","valueSource":"value"},{"rules":[{"field":"Account.entity","value":"GSBZ","operator":"=","valueSource":"value"},{"field":"Account.mfid class code","value":"\"\"","operator":"!=","valueSource":"value"}],"combinator":"and","not":false}],"combinator":"or","not":false},{"field":"Transaction.type","value":"trade","operator":"=","valueSource":"value"},{"field":"Transaction.type","value":"buy,short,sell","operator":"contains","valueSource":"value"},{"field":"Transaction.excode","value":"DE","operator":"!=","valueSource":"value"},{"field":"Transaction.ccpstatus","value":"Done","operator":"!=","valueSource":"value"},{"field":"Product.ucits","value":"No, Unknown","operator":"contains","valueSource":"value"},{"rules":[{"rules":[{"field":"Account.priips","value":"UK","operator":"contains","valueSource":"value"},{"field":"Product.uk kidlanguage","value":"available","operator":"=","valueSource":"value"}],"combinator":"and","not":false},{"rules":[{"rules":[{"field":"Account.priips","value":"EU","operator":"=","valueSource":"value"},{"field":"Account.priips","value":"CH","operator":"=","valueSource":"value"}],"combinator":"or","not":false},{"field":"Product.eukidlanguagr","value":"available","operator":"=","valueSource":"value"},{"field":"Product.eukidlanguagr","value":"atleast one","operator":"=","valueSource":"value"}],"combinator":"and","not":false}],"combinator":"or","not":false},{"rules":[{"field":"Product.type","value":"ETF","operator":"=","valueSource":"value"},{"field":"Product.type","value":"ETN","operator":"=","valueSource":"value"},{"field":"Product.type","value":"mutual fund","operator":"=","valueSource":"value"}],"combinator":"or","not":false}],"combinator":"and","not":false}
function  ViewRuleEngine (){
  const [query, setQuery] = useState<RuleGroupType>(initialQuery);

  return (
    <>
    <QueryBuilderBootstrap>
      <QueryBuilder
        fields={fields}
        query={query}
        disabled
        onQueryChange={(q) => setQuery(q)}
        showCombinatorsBetweenRules
        controlClassnames={{ queryBuilder: 'queryBuilder-branches' }}
      />
    </QueryBuilderBootstrap>
    </>
);
};


export default ViewRuleEngine;