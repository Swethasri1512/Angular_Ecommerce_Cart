import { useState } from "react";
import "../styles/index.scss";
import RuleTableNestedUI from "./RuleTable";
import {  RulesData, RuleData } from "../interfaces/rules";
import usePostHttp from "../hooks/useSearchRuleHook";


 function SearchRuleEngine() {
  const [selectedValue, setselectedValue] = useState<string>("");
  const [searchText, setsearchText] = useState<string>('');
  const [showTable, setShowRuleTable] = useState<boolean>(false);
  const [rulesDataArray, setRulesDataArray] = useState<RulesData[]>([]);
  let [error,sendRequest] = usePostHttp();


function getResponse(arrayRules:RulesData[]){
 setRulesDataArray(arrayRules);
}
  const getRuleData = () => {
    setShowRuleTable(true);
    let key = selectedValue?.toString();
    const request = {
      [key]: searchText,
    };
    sendRequest("http://localhost:8080/searchRules",'POST',request,getResponse);
  };

  const handleChange = (e:{target:{value:string}}) => {
    setselectedValue(e?.target?.value);
  };

  const handleChangeInput = (e:{target:{value:string}}) => {
    setsearchText(e.target.value);
  };

  return (
    <div className="container  min-vh-100 py-4">
      <div className="row">
        <div className="col-md-5 mx-auto">
          <div className="small mt-3 fw-light mb-3 info">Search Rules</div>

          <div className="input-group">
            <div className="">
              <select
                value={selectedValue}
                onChange={handleChange}
                className="form-select"
                aria-label="Default select example"
              >
                <option selected value="">Search Rule</option>
                <option value="category">Category</option>
                <option value="ruleName">Rule Name</option>
                <option value="subCategory">Sub-Category</option>
                <option value="tag">Tag</option>
              </select>
            </div>

            <input
              className="form-control ml-5 border-end-0 border"
              type="text"
              id="example-search-input"
              value={searchText}
              onChange={handleChangeInput}
            />
            <span className="input-group-append">
              <button
                onClick={getRuleData}
                className="btn btn-outline-secondary bg-info border-bottom-0 border  ms-n5"
                type="button"
              >
                Search Rule{" "}
              </button>
            </span>
          </div>
        </div>
      </div>

      <div className="App1">
        {showTable ? <RuleTableNestedUI rulesData={rulesDataArray} /> : <></>}
      </div>

    </div>
  );
}


export default SearchRuleEngine;