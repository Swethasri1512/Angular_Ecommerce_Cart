import { useState, useEffect, useRef } from "react";
import BootstrapTable from "react-bootstrap-table-next";
import filterFactory, { textFilter } from "react-bootstrap-table2-filter";
import {  RulesData } from "../interfaces/rules";
import ViewRuleEngine from "./ViewRuleEngine";

function RuleTableNestedUI(props:{rulesData:RulesData[]}) {
  const [rules, setRules] = useState<RulesData[]>([]);
  const ref = useRef<HTMLHeadingElement>(null);
  const [show, setShow] = useState<boolean>(false);

  useEffect(() => {
    getData();
  });
  const getData = () => {
    setRules(props.rulesData);
  };
const columns = [
    {
      dataField: "id",
      text: "Rule ID",
      sort: true,
    },
    {
      dataField: "ruleName",
      text: "Rule Name",
      sort: true,
      filter: textFilter(),
    },
    {
      dataField: "tag",
      text: "Tag",
      filter: textFilter(),
      sort: true,
    },
    {
      dataField: "lastModifiedBy",
      text: "Last Modified By",
      sort: true,
    },
    {
      dataField: "lastUpdatedBy",
      text: "Last Updated By",
      sort: true,
    },
    {
      dataField: "databasePkey",
      text: "View Rule",
      formatter: ( row:{ruleContent:{}}) => {
        const content = row?.ruleContent;
        return (
          <button
            onClick={() => handleShow(content)}
            className="btn btn-primary btn-xs"
          >
            View
          </button>
        );
      },
    },
  ];

  const handleShow = (ruleContent:{}) => {
    ref?.current?.scrollIntoView({ behavior: "smooth" });
   
    setShow(true);
  };

  return (
    <div className="RuleTable">
      <BootstrapTable
        bootstrap4
        keyField="_id"
        filter={filterFactory()}
        data={rules}
        columns={columns}
      />

      {show ? (
        <div ref={ref}>
          <span className="f-bold">When</span>
          <ViewRuleEngine/>
        </div>
      ) : null}
    </div>
  );
}

export default RuleTableNestedUI;
