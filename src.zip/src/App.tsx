import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import "./styles/index.scss";

import Nav from "./components/Nav";
import SearchRuleEngine from "./components/SearchRuleEngine";
import UploadRule from "./components/UploadRuleEngine";

const App: React.FunctionComponent<{}> = () => {

  return (
    <div className="App">
      <>
        <BrowserRouter>
          <Nav />
          <Switch>
          <Route path="/" exact>
              <SearchRuleEngine/>
            </Route>
            <Route path="/search" exact>
              <SearchRuleEngine/>
            </Route>
            <Route path="/upload">
              <UploadRule />
            </Route>
          </Switch>
        </BrowserRouter>
      </>
    </div>
  );
};

export default App;
