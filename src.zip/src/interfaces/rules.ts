export interface RuleData {
    _id:{
        timestamp: number;
        date: Date;
    }
    tag: string;
    category: string;
    subCategory: string;
    ruleName: string;
    rulesData :RulesData
}

export interface Response{
    data:RuleData;
}

export interface RulesData {
    id: number;
    ruleName: string;
    ruleDescription: string;
    active: boolean;
    tag: string[];
    ruleDrl: string;
    version: number;
    lastUpdatedBy: string;
    lastModifiedBy: string;
    ruleObjects: [];
    ruleContent:RuleContent;
}

export interface RuleContent{
    when:RuleProperties[];
    then: RuleProperties[];
}

export interface  RuleProperties{
    propertyName: string;
    value: string[];
    operator: string;
}


