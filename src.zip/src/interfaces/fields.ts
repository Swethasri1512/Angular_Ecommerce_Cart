import type { Field, RuleType } from 'react-querybuilder';

export const validator = (r:RuleType) => !!r.value;

export const fields :Field[]= [
  {
    name: 'Account.entity',
    label: 'Account Entity',
    
  },
  {
    name: 'Account.mfid class code',
    label: 'Account mfid class code',
   
  },
  {
    name: 'Transaction.type',
    label: 'Transaction.type',
   
  },
  {
    name: 'Transaction.excode',
    label: 'Transaction.excode',
   
  },
  {
    name: 'Transaction.ccpstatus',
    label: 'Transaction.ccpstatus',
   
  },
  {
    name: 'Product.ucits',
    label: 'Product.ucits',
   
  },
  {
    name: 'Account.priips',
    label: 'Account.priips',
    
  },
  {
    name: 'Product.uk kidlanguage',
    label: 'Product.ukkidlanguage',
   
  },
  {
    name: 'Product.eukidlanguagr',
    label: 'Product.eukidlanguage',
   
  },
  {
    name: 'Product.type',
    label: 'Product.type',
   
  },
  { name: 'age', label: 'Age', inputType: 'number', validator },
  
  { name: 'height', label: 'Height', validator },
  { name: 'job', label: 'Job', validator },
  { name: 'description', label: 'Description', valueEditorType: 'textarea' },
  { name: 'birthdate', label: 'Birth Date', inputType: 'date' },
  { name: 'datetime', label: 'Show Time', inputType: 'datetime-local' },
  { name: 'alarm', label: 'Daily Alarm', inputType: 'time' },
  {
    name: 'groupedField1',
    label: 'Grouped Field 1',
    comparator: 'groupNumber',
    groupNumber: 'group1',
    valueSources: ['field', 'value'],
  },
  {
    name: 'groupedField2',
    label: 'Grouped Field 2',
    comparator: 'groupNumber',
    groupNumber: 'group1',
    valueSources: ['field', 'value'],
  },
  {
    name: 'groupedField3',
    label: 'Grouped Field 3',
    comparator: 'groupNumber',
    groupNumber: 'group1',
    valueSources: ['field', 'value'],
  },
  {
    name: 'groupedField4',
    label: 'Grouped Field 4',
    comparator: 'groupNumber',
    groupNumber: 'group1',
    valueSources: ['field', 'value'],
  },
];